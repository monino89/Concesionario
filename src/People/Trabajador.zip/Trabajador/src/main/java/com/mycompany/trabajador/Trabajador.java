
package com.mycompany.trabajador;

public class Trabajador  {
    private String codigo;
    private String cargo;
    private int añosExperiencia;
    
    public Trabajador(){
        this.codigo="";
        this.cargo="";
        this.añosExperiencia=0;
    }
    
    public Trabajador(String codigo, String cargo, int añosExperiecia){
    
    this.setCodigo(codigo);
    this.setCargo(cargo);
    this.setAñosExperiencia(añosExperiencia);  
}
    public final void setCodigo(String codigo){
        if (codigo == null || codigo.isBlank() || codigo.matches(".*[-!@#$%^&*()+=<>?/].*")){
            throw new IllegalArgumentException("Codigo no valido.");
        }
        else{
            this.codigo = codigo;
        }
    }
    public final void setCargo (String cargo){
        if (cargo == null || cargo.isBlank() || cargo.matches(".*[-!@#$%^&*()+=<>?/].*")){
            throw new IllegalArgumentException("Cargo no valido.");
        }
        else{
            this.cargo = cargo;
        }
    }
    public final void setAñosExperiencia (int añosExperiencia){
        if(añosExperiencia>0){
            this.añosExperiencia = añosExperiencia;
        }else{
            throw new IllegalArgumentException("Los años de experiencia deben ser mayores a 0");
        }
    }
    protected String getCodigo(){
        return codigo;
    }
    protected String getCargo(){
        return cargo;
    }
    protected int getAñosExperiencia(){
        return añosExperiencia;
    }
    @Override
    public String toString(){
        String temp = "Codigo: " + this.codigo + ", Cargo: " + this.cargo + "añosExperiencia: " + this.añosExperiencia;
        return temp;
    }
    public String trabajadoresDisponibles(){
        return "El trabajador con codigo" + codigo + "esta disponible para nuevas tareas";
}
}